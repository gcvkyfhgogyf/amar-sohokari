# আমার সহকারী (Amar Shohayok)

বাংলা ভাষার Android reading assistant starter project. Kotlin + Jetpack Compose.

## এই সংস্করণে যা আছে

- বাংলা UI এবং প্রিমিয়াম navy/emerald visual theme
- PDF import করে ব্যক্তিগত লাইব্রেরিতে সংরক্ষণ
- PDF cover thumbnail এবং built-in PDF page reader
- শেষ পড়া পৃষ্ঠা সংরক্ষণ
- selectable-text PDF থেকে প্রতি পৃষ্ঠার text extraction
- বইভিত্তিক দৈনিক reading schedule
- নির্ধারিত সময়ে Messenger feed-এ পূর্ণ extracted reading text তৈরি
- বড় পড়ার অংশ একই chat message-এ দেখানো (UI scrollable)
- পড়া সম্পন্ন / আবার অসম্পূর্ণ করার ব্যবস্থা
- Home dashboard, library, messenger, progress এবং settings
- Device Admin permission ব্যবহার করে Screen Lock Timer
- GitHub Actions workflow দিয়ে debug APK build

## গুরুত্বপূর্ণ সীমাবদ্ধতা

এটি প্রথম কার্যকর ভিত্তি সংস্করণ, সম্পূর্ণ বাণিজ্যিক/production release নয়।

- PDF থেকে text extraction কাজ করে যখন PDF-এ selectable text থাকে। স্ক্যান করা image-only PDF-এর জন্য Bengali OCR এই সংস্করণে এখনো যুক্ত করা হয়নি।
- PDF import-ই বর্তমানে চালু। EPUB, DOCX, TXT import এবং কুরআন/হাদিসের আলাদা verified content module পরবর্তী ধাপে যোগ করতে হবে।
- Reading schedule Android AlarmManager ব্যবহার করে। Exact alarm permission না দিলে Android সময়ে কিছুটা বিলম্ব করতে পারে। Settings থেকে নির্দিষ্ট সময়ের alarm permission চালু করা যায়।
- Screen Lock Timer চালাতে ব্যবহারকারীকে Device Admin permission নিজে চালু করতে হবে। Android permission ছাড়া অ্যাপ ফোন লক করতে পারে না।
- অ্যাপের ডেটা বর্তমানে ফোনের local SQLite database ও app-private storage-এ থাকে। Cloud sync নেই।

## GitHub Actions থেকে APK বানানো

1. GitHub-এ একটি repository তৈরি করো।
2. `AmarShohayok.zip` ফাইলটি repository-র root-এ upload করো।
3. প্রথমবার হলে `.github/workflows/build-apk.yml` workflow ফাইলটিও repository-তে রাখতে হবে। ZIP-এর ভেতরে workflow আছে, কিন্তু GitHub ZIP-কে নিজে থেকে extract করে workflow চালায় না।
4. Actions tab → **Build Amar Shohayok APK** → **Run workflow** চাপো।
5. Build সফল হলে workflow run-এর নিচে `amar-shohayok-debug-apk` artifact থেকে APK download করা যাবে।

বিকল্পভাবে ZIP extract করে এর ভেতরের সব project file repository root-এ upload করলে একই workflow সরাসরি project build করবে।

## Android permissions

- Notifications: Android 13+ এ runtime permission.
- Exact alarms: optional special access for more punctual schedules.
- Device Admin: required only for Screen Lock Timer.

## Package

`com.amarshohayok.app`
