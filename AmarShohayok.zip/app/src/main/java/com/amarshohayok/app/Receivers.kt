package com.amarshohayok.app

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.amarshohayok.app.data.AppDatabase
import com.amarshohayok.app.reader.PdfTools
import java.io.File
import java.util.Calendar

class LockDeviceAdminReceiver : DeviceAdminReceiver()

class TimerReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val admin = ComponentName(context, LockDeviceAdminReceiver::class.java)
        if (dpm.isAdminActive(admin)) dpm.lockNow()
        else notify(context, "স্ক্রিন লক টাইমার", "সময় শেষ হয়েছে। স্ক্রিন লক করতে Device Admin অনুমতি চালু করুন।", 9101)
    }
}

class ScheduleReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val scheduleId = intent?.getLongExtra("schedule_id", -1L) ?: -1L
        val pending = goAsync()
        Thread {
            try {
                val db = AppDatabase(context)
                val schedule = db.schedules().firstOrNull { it.id == scheduleId && it.enabled }
                if (schedule != null) {
                    val book = db.book(schedule.bookId)
                    if (book != null) {
                        val textPath = book.filePath.removeSuffix(".pdf") + ".pages.txt"
                        val start = (db.messages().filter { it.bookId == book.id }.maxOfOrNull { it.pageEnd } ?: 0) + 1
                        val end = (start + schedule.pagesPerSession - 1).coerceAtMost(book.pageCount)
                        if (start <= book.pageCount) {
                            val content = PdfTools.readPages(textPath, start, end)
                            val title = "আজকের পড়া: পৃষ্ঠা $start–$end"
                            val msgId = db.addMessage(book, title, start, end, content, System.currentTimeMillis())
                            notify(context, book.title, "$title\n\n${content.take(240)}", msgId.toInt())
                        }
                    }
                    scheduleNext(context, schedule.id, schedule.hour, schedule.minute)
                }
            } catch (_: Exception) {
                notify(context, "আমার সহকারী", "নির্ধারিত পড়া তৈরি করা যায়নি। বই ও PDF টেক্সট পরীক্ষা করুন।", 9200)
            } finally { pending.finish() }
        }.start()
    }

    companion object {
        fun scheduleNext(context: Context, id: Long, hour: Int, minute: Int) {
            val cal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY,hour);set(Calendar.MINUTE,minute);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0); if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR,1) }
            val intent = Intent(context, ScheduleReceiver::class.java).putExtra("schedule_id", id)
            val pi = PendingIntent.getBroadcast(context, id.toInt(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            if (Build.VERSION.SDK_INT >= 31 && am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
            else if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi) else am.set(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED) {
            AppDatabase(context).schedules().filter { it.enabled }.forEach { ScheduleReceiver.scheduleNext(context,it.id,it.hour,it.minute) }
        }
    }
}

fun schedulePhoneLock(context: Context, minutes: Int) {
    val intent = Intent(context, TimerReceiver::class.java)
    val pi = PendingIntent.getBroadcast(context, 8001, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val at = System.currentTimeMillis() + minutes * 60_000L
    if (Build.VERSION.SDK_INT >= 31 && am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
    else if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi) else am.set(AlarmManager.RTC_WAKEUP, at, pi)
}

private fun notify(context: Context, title: String, body: String, id: Int) {
    val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(NotificationChannel("reading", "পড়ার মেসেজ", NotificationManager.IMPORTANCE_HIGH))
    val open = PendingIntent.getActivity(context, 7000, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    val n = NotificationCompat.Builder(context,"reading").setSmallIcon(R.drawable.ic_app_logo).setContentTitle(title).setContentText(body).setStyle(NotificationCompat.BigTextStyle().bigText(body)).setContentIntent(open).setAutoCancel(true).build()
    manager.notify(id,n)
}
