package com.amarshohayok.app.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

 data class Book(
    val id: Long, val title: String, val author: String, val filePath: String,
    val pageCount: Int, val coverPath: String, val lastPage: Int, val addedAt: Long
)

data class ReadingMessage(
    val id: Long, val bookId: Long, val bookTitle: String, val title: String,
    val pageStart: Int, val pageEnd: Int, val content: String,
    val scheduledAt: Long, val status: String, val createdAt: Long
)

data class ReadingSchedule(
    val id: Long, val bookId: Long, val hour: Int, val minute: Int,
    val pagesPerSession: Int, val enabled: Boolean
)

class AppDatabase(context: Context) : SQLiteOpenHelper(context, "amar_shohayok.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE books(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,author TEXT NOT NULL,filePath TEXT NOT NULL,pageCount INTEGER NOT NULL,coverPath TEXT NOT NULL,lastPage INTEGER NOT NULL DEFAULT 0,addedAt INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE messages(id INTEGER PRIMARY KEY AUTOINCREMENT,bookId INTEGER NOT NULL,bookTitle TEXT NOT NULL,title TEXT NOT NULL,pageStart INTEGER NOT NULL,pageEnd INTEGER NOT NULL,content TEXT NOT NULL,scheduledAt INTEGER NOT NULL,status TEXT NOT NULL,createdAt INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE schedules(id INTEGER PRIMARY KEY AUTOINCREMENT,bookId INTEGER NOT NULL,hour INTEGER NOT NULL,minute INTEGER NOT NULL,pagesPerSession INTEGER NOT NULL,enabled INTEGER NOT NULL DEFAULT 1)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun addBook(title: String, author: String, filePath: String, pages: Int, coverPath: String): Long {
        val v = ContentValues().apply { put("title", title); put("author", author); put("filePath", filePath); put("pageCount", pages); put("coverPath", coverPath); put("lastPage", 0); put("addedAt", System.currentTimeMillis()) }
        return writableDatabase.insert("books", null, v)
    }
    fun books(): List<Book> {
        val out = mutableListOf<Book>()
        readableDatabase.rawQuery("SELECT * FROM books ORDER BY addedAt DESC", null).use { c ->
            while (c.moveToNext()) out += Book(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getInt(4),c.getString(5),c.getInt(6),c.getLong(7))
        }; return out
    }
    fun book(id: Long): Book? = books().firstOrNull { it.id == id }
    fun updateLastPage(id: Long, page: Int) { writableDatabase.execSQL("UPDATE books SET lastPage=? WHERE id=?", arrayOf(page,id)) }
    fun deleteBook(id: Long) { writableDatabase.delete("books", "id=?", arrayOf(id.toString())); writableDatabase.delete("schedules", "bookId=?", arrayOf(id.toString())) }
    fun addSchedule(bookId: Long, hour: Int, minute: Int, pages: Int): Long {
        val v = ContentValues().apply { put("bookId",bookId); put("hour",hour); put("minute",minute); put("pagesPerSession",pages); put("enabled",1) }
        return writableDatabase.insert("schedules",null,v)
    }
    fun schedules(): List<ReadingSchedule> {
        val out= mutableListOf<ReadingSchedule>()
        readableDatabase.rawQuery("SELECT * FROM schedules ORDER BY hour,minute",null).use { c -> while(c.moveToNext()) out += ReadingSchedule(c.getLong(0),c.getLong(1),c.getInt(2),c.getInt(3),c.getInt(4),c.getInt(5)==1) }
        return out
    }
    fun addMessage(book: Book, title: String, start: Int, end: Int, content: String, due: Long): Long {
        val v=ContentValues().apply { put("bookId",book.id);put("bookTitle",book.title);put("title",title);put("pageStart",start);put("pageEnd",end);put("content",content);put("scheduledAt",due);put("status","অসম্পূর্ণ");put("createdAt",System.currentTimeMillis()) }
        return writableDatabase.insert("messages",null,v)
    }
    fun messages(): List<ReadingMessage> {
        val out= mutableListOf<ReadingMessage>()
        readableDatabase.rawQuery("SELECT * FROM messages ORDER BY createdAt DESC",null).use { c -> while(c.moveToNext()) out += ReadingMessage(c.getLong(0),c.getLong(1),c.getString(2),c.getString(3),c.getInt(4),c.getInt(5),c.getString(6),c.getLong(7),c.getString(8),c.getLong(9)) }
        return out
    }
    fun updateMessageStatus(id: Long, status: String) { writableDatabase.execSQL("UPDATE messages SET status=? WHERE id=?", arrayOf(status,id)) }
}
