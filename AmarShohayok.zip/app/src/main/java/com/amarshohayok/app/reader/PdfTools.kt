package com.amarshohayok.app.reader

import android.content.Context
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.File
import java.io.FileOutputStream

object PdfTools {
    fun importPdf(context: Context, uriString: String, displayName: String): ImportedPdf {
        val uri = android.net.Uri.parse(uriString)
        val safe = displayName.substringBeforeLast('.', displayName).replace(Regex("[^\\p{L}\\p{N}_-]"), "_").take(50).ifBlank { "book" }
        val pdf = File(context.filesDir, "${System.currentTimeMillis()}_$safe.pdf")
        context.contentResolver.openInputStream(uri).use { input -> requireNotNull(input) { "ফাইলটি খোলা যায়নি" }; FileOutputStream(pdf).use { output -> input.copyTo(output) } }
        PDFBoxResourceLoader.init(context)
        val pageTexts = mutableListOf<String>()
        PDDocument.load(pdf).use { doc ->
            val count = doc.numberOfPages
            for (p in 1..count) {
                val stripper = PDFTextStripper().apply { startPage = p; endPage = p }
                pageTexts += stripper.getText(doc).trim()
            }
            val textFile = File(pdf.parentFile, pdf.nameWithoutExtension + ".pages.txt")
            textFile.writeText(pageTexts.joinToString("\n\u000c\n"), Charsets.UTF_8)
            val cover = File(pdf.parentFile, pdf.nameWithoutExtension + ".jpg")
            renderPage(pdf, 0, 900)?.let { bitmap -> FileOutputStream(cover).use { bitmap.compress(Bitmap.CompressFormat.JPEG, 86, it) }; bitmap.recycle() }
            return ImportedPdf(pdf.absolutePath, textFile.absolutePath, cover.absolutePath, count, pageTexts.count { it.isNotBlank() })
        }
    }

    fun renderPage(pdfFile: File, pageIndex: Int, width: Int = 1200): Bitmap? {
        return try {
            val fd = ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_READ_ONLY)
            PdfRenderer(fd).use { renderer ->
                if (pageIndex !in 0 until renderer.pageCount) return null
                renderer.openPage(pageIndex).use { page ->
                    val height = (width.toFloat() * page.height / page.width).toInt().coerceAtLeast(1)
                    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                    bitmap.eraseColor(android.graphics.Color.WHITE)
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    bitmap
                }
            }
        } catch (_: Exception) { null }
    }

    fun readPages(textPath: String, start: Int, end: Int): String {
        val text = File(textPath).takeIf { it.exists() }?.readText(Charsets.UTF_8) ?: return "এই PDF থেকে লেখা পড়া যায়নি। মূল বই খুলে দেখুন।"
        val pages = text.split("\u000c")
        val selected = (start..end).mapNotNull { n -> pages.getOrNull(n - 1)?.trim()?.takeIf { it.isNotBlank() }?.let { "পৃষ্ঠা $n\n$it" } }
        return if (selected.isEmpty()) "এই পৃষ্ঠাগুলো থেকে কোনো টেক্সট পাওয়া যায়নি। PDF-টি স্ক্যান করা ছবি হতে পারে। OCR প্রয়োজন। মূল বই খুলে পড়ুন।" else selected.joinToString("\n\n──────────\n\n")
    }
}

data class ImportedPdf(val pdfPath: String, val textPath: String, val coverPath: String, val pages: Int, val extractedPages: Int)
