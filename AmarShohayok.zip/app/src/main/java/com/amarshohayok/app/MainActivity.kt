package com.amarshohayok.app

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.content.pm.PackageManager
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryBooks
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.MoreTime
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import com.amarshohayok.app.data.AppDatabase
import com.amarshohayok.app.data.Book
import com.amarshohayok.app.data.ReadingMessage
import com.amarshohayok.app.reader.PdfTools
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val Navy = Color(0xFF172B4D)
private val Green = Color(0xFF16866A)
private val Gold = Color(0xFFC6A66B)
private val Canvas = Color(0xFFF7F8FA)
private val Ink = Color(0xFF202735)
private val Muted = Color(0xFF7A8494)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(247,248,250)
        window.navigationBarColor = android.graphics.Color.rgb(247,248,250)
        window.decorView.systemUiVisibility = android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1001)
        }
        setContent { AppRoot(this) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AppRoot(activity: Activity) {
    val db = remember { AppDatabase(activity) }
    var tab by remember { mutableStateOf("হোম") }
    var books by remember { mutableStateOf(db.books()) }
    var messages by remember { mutableStateOf(db.messages()) }
    var selectedBook by remember { mutableStateOf<Book?>(null) }
    var listFilter by remember { mutableStateOf<String?>(null) }
    var showSchedule by remember { mutableStateOf<Book?>(null) }
    var importing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    fun refresh() { books = db.books(); messages = db.messages() }
    LaunchedEffect(Unit) { while (true) { delay(4000); refresh() } }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            importing = true
            scope.launch {
                val result = withContext(Dispatchers.IO) {
                    val name = queryDisplayName(activity, uri)
                    PdfTools.importPdf(activity, uri.toString(), name)
                }
                val name = queryDisplayName(activity, uri).substringBeforeLast('.')
                db.addBook(name, "অজানা লেখক", result.pdfPath, result.pages, result.coverPath)
                importing = false
                refresh()
            }
        }
    }

    MaterialTheme(colorScheme = MaterialTheme.colorScheme.copy(primary = Navy, secondary = Green, background = Canvas, surface = Color.White)) {
        Surface(color = Canvas) {
            if (selectedBook != null) {
                PdfReader(activity, selectedBook!!, db, onBack = { selectedBook = null; refresh() })
            } else {
                Scaffold(
                    containerColor = Canvas,
                    topBar = {
                        TopAppBar(
                            title = { Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(36.dp).clip(RoundedCornerShape(12.dp)).background(Navy), contentAlignment = Alignment.Center) {
                                    Icon(Icons.Filled.AutoStories, null, tint = Color.White, modifier = Modifier.size(22.dp))
                                }
                                Spacer(Modifier.width(10.dp)); Column { Text("আমার সহকারী", fontWeight = FontWeight.Bold, color = Navy, fontSize = 19.sp); Text("পড়া, সময় ও অভ্যাস", color = Muted, fontSize = 11.sp) }
                            } },
                            colors = TopAppBarDefaults.topAppBarColors(containerColor = Canvas)
                        )
                    },
                    bottomBar = {
                        NavigationBar(containerColor = Color.White, tonalElevation = 8.dp) {
                            val nav = listOf(Triple("হোম", Icons.Filled.Home, ""), Triple("মেসেঞ্জার", Icons.Filled.Chat, ""), Triple("লাইব্রেরি", Icons.Filled.LibraryBooks, ""), Triple("অগ্রগতি", Icons.Filled.TrendingUp, ""), Triple("সেটিংস", Icons.Filled.Settings, ""))
                            nav.forEach { item -> NavigationBarItem(selected = tab == item.first, onClick = { tab = item.first; listFilter = null }, icon = { Icon(item.second, null) }, label = { Text(item.first, fontSize = 10.sp) }) }
                        }
                    }
                ) { padding ->
                    Box(Modifier.padding(padding).fillMaxSize()) {
                        when (tab) {
                            "হোম" -> HomeScreen(books, messages, onOpen = { key -> listFilter = key; tab = when (key) { "বই" -> "লাইব্রেরি"; "ধারাবাহিক দিন" -> "অগ্রগতি"; else -> "মেসেঞ্জার" } }, onLock = { minutes -> startLock(activity, minutes) })
                            "মেসেঞ্জার" -> MessengerScreen(messages, listFilter, onStatus = { id, status -> db.updateMessageStatus(id,status); refresh() }, onOpenBook = { id -> selectedBook = db.book(id) })
                            "লাইব্রেরি" -> LibraryScreen(books, importing, onAdd = { picker.launch(arrayOf("application/pdf")) }, onOpen = { selectedBook = it }, onSchedule = { showSchedule = it }, onDelete = { db.deleteBook(it.id); File(it.filePath).delete(); File(it.filePath.removeSuffix(".pdf")+".pages.txt").delete(); refresh() })
                            "অগ্রগতি" -> ProgressScreen(books, messages)
                            else -> SettingsScreen(activity, onLock = { startLock(activity,it) })
                        }
                    }
                }
            }
        }
    }

    if (showSchedule != null) {
        ScheduleDialog(book = showSchedule!!, onDismiss = { showSchedule = null }, onSave = { hour, minute, pages ->
            val id = db.addSchedule(showSchedule!!.id,hour,minute,pages)
            ScheduleReceiver.scheduleNext(activity,id,hour,minute)
            showSchedule = null
            refresh()
        })
    }
}

@Composable
private fun HomeScreen(books: List<Book>, messages: List<ReadingMessage>, onOpen: (String) -> Unit, onLock: (Int) -> Unit) {
    val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    val todays = messages.filter { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(it.createdAt)) == today }
    val completed = messages.count { it.status == "সম্পন্ন" }
    val incomplete = messages.count { it.status != "সম্পন্ন" }
    val streakDays = currentStreak(messages)
    LazyColumn(contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Card(shape = RoundedCornerShape(26.dp), colors = CardDefaults.cardColors(containerColor = Navy), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp)) {
                    Text(greeting(), color = Color.White.copy(alpha=.8f), fontSize=13.sp)
                    Spacer(Modifier.height(6.dp)); Text("আজ একটু এগিয়ে যাও।", color=Color.White, fontSize=23.sp, fontWeight=FontWeight.Bold)
                    Spacer(Modifier.height(14.dp)); Row(verticalAlignment=Alignment.CenterVertically) {
                        Box(Modifier.weight(1f)) { Text("তোমার পড়ার যাত্রা প্রতিদিনের ছোট পদক্ষেপে তৈরি হয়।", color=Color.White.copy(alpha=.78f), fontSize=12.sp) }
                        Box(Modifier.size(54.dp).clip(CircleShape).background(Green),contentAlignment=Alignment.Center) { Icon(Icons.Filled.AutoStories,null,tint=Color.White,modifier=Modifier.size(28.dp)) }
                    }
                }
            }
        }
        item { Text("তোমার ড্যাশবোর্ড", fontSize=17.sp, fontWeight=FontWeight.Bold, color=Ink) }
        item {
            Column(verticalArrangement=Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                    MetricCard("আজকের মোট পড়া",todays.size.toString(),"আজকের তালিকা",Green,Modifier.weight(1f)){onOpen("আজকের মোট পড়া")}
                    MetricCard("সম্পূর্ণ পড়া",completed.toString(),"সফলভাবে শেষ",Navy,Modifier.weight(1f)){onOpen("সম্পূর্ণ পড়া")}
                }
                Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                    MetricCard("অসম্পূর্ণ পড়া",incomplete.toString(),"বাকি রয়েছে",Color(0xFFB7791F),Modifier.weight(1f)){onOpen("অসম্পূর্ণ পড়া")}
                    MetricCard("মোট বই",books.size.toString(),"লাইব্রেরিতে",Green,Modifier.weight(1f)){onOpen("বই")}
                }
                MetricCard("ধারাবাহিক দিন",streakDays.toString(),"যে দিনগুলোতে পড়া সম্পন্ন",Gold,Modifier.fillMaxWidth()){onOpen("ধারাবাহিক দিন")}
            }
        }
        item {
            Row(verticalAlignment=Alignment.CenterVertically) { Text("দ্রুত স্ক্রিন লক", fontWeight=FontWeight.Bold, color=Ink, fontSize=17.sp); Spacer(Modifier.weight(1f)); Icon(Icons.Filled.Lock,null,tint=Green) }
            Card(shape=RoundedCornerShape(20.dp), colors=CardDefaults.cardColors(containerColor=Color.White)) {
                Column(Modifier.padding(15.dp)) {
                    Text("সময় শেষ হলে ফোন লক হবে", color=Muted, fontSize=12.sp)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { listOf(5,10,15,30).forEach { n -> FilledTonalButton(onClick={onLock(n)}, colors=ButtonDefaults.filledTonalButtonColors(containerColor=Color(0xFFEAF3F0),contentColor=Green), modifier=Modifier.weight(1f), contentPadding=PaddingValues(4.dp)) { Text("$n মিনিট",fontSize=11.sp) } } }
                }
            }
        }
        item {
            Row(verticalAlignment=Alignment.CenterVertically) { Text("সাম্প্রতিক পড়া", fontWeight=FontWeight.Bold, color=Ink, fontSize=17.sp); Spacer(Modifier.weight(1f)); Text("সব দেখুন",color=Green,fontSize=12.sp,modifier=Modifier.clickable{onOpen("আজকের মোট পড়া")}) }
        }
        if (messages.isEmpty()) item { EmptyState("এখনো কোনো পড়া আসেনি", "লাইব্রেরিতে PDF বই যোগ করে পড়ার সময়সূচি তৈরি করো।") }
        items(messages.take(3)) { msg -> MessagePreview(msg) { onOpen("আজকের মোট পড়া") } }
    }
}

@Composable
private fun MetricCard(title: String, value: String, hint: String, color: Color, modifier: Modifier, onClick: () -> Unit) {
    Card(modifier.clickable(onClick=onClick), shape=RoundedCornerShape(20.dp), colors=CardDefaults.cardColors(containerColor=Color.White), elevation=CardDefaults.cardElevation(1.dp)) {
        Column(Modifier.padding(15.dp)) {
            Box(Modifier.size(34.dp).clip(RoundedCornerShape(11.dp)).background(color.copy(alpha=.11f)),contentAlignment=Alignment.Center) { Icon(Icons.Filled.AutoStories,null,tint=color,modifier=Modifier.size(19.dp)) }
            Spacer(Modifier.height(12.dp)); Text(value,fontSize=26.sp,fontWeight=FontWeight.Bold,color=Ink); Text(title,fontSize=13.sp,fontWeight=FontWeight.SemiBold,color=Ink); Spacer(Modifier.height(3.dp)); Text(hint,fontSize=10.sp,color=Muted)
        }
    }
}

@Composable
private fun LibraryScreen(books: List<Book>, importing: Boolean, onAdd: () -> Unit, onOpen: (Book) -> Unit, onSchedule: (Book) -> Unit, onDelete: (Book) -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal=16.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically, modifier=Modifier.padding(top=14.dp,bottom=12.dp)) {
            Column(Modifier.weight(1f)) { Text("আমার লাইব্রেরি",fontSize=22.sp,fontWeight=FontWeight.Bold,color=Navy); Text("তোমার সব বই এক জায়গায়",fontSize=12.sp,color=Muted) }
            Button(onClick=onAdd, shape=RoundedCornerShape(14.dp), colors=ButtonDefaults.buttonColors(containerColor=Green)) { Icon(Icons.Filled.Book,null,modifier=Modifier.size(17.dp)); Spacer(Modifier.width(5.dp)); Text("বই যোগ") }
        }
        if (importing) LinearProgressText("PDF বই যোগ করা হচ্ছে…")
        if (books.isEmpty()) { EmptyState("লাইব্রেরি এখনো খালি", "PDF বই যোগ করো। বইয়ের সম্পূর্ণ পৃষ্ঠা এখানে পড়তে পারবে।") }
        else LazyVerticalGrid(columns=GridCells.Fixed(2), contentPadding=PaddingValues(bottom=20.dp), horizontalArrangement=Arrangement.spacedBy(12.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
            items(books) { book ->
                Card(shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=Color.White),modifier=Modifier.fillMaxWidth()) {
                    Column {
                        val cover = remember(book.coverPath) { BitmapFactory.decodeFile(book.coverPath) }
                        if (cover != null) Image(cover.asImageBitmap(),null,Modifier.fillMaxWidth().height(150.dp).clickable{onOpen(book)}, contentScale=androidx.compose.ui.layout.ContentScale.Crop)
                        else Box(Modifier.fillMaxWidth().height(150.dp).background(Color(0xFFEAF0F5)).clickable{onOpen(book)},contentAlignment=Alignment.Center) { Icon(Icons.Filled.MenuBook,null,tint=Navy,modifier=Modifier.size(52.dp)) }
                        Column(Modifier.padding(11.dp)) {
                            Text(book.title,fontSize=14.sp,fontWeight=FontWeight.Bold,color=Ink,maxLines=2,overflow=TextOverflow.Ellipsis)
                            Text(book.author,fontSize=11.sp,color=Muted,maxLines=1)
                            Text("${book.pageCount} পৃষ্ঠা",fontSize=10.sp,color=Muted)
                            Spacer(Modifier.height(8.dp))
                            Button(onClick={onOpen(book)},modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(11.dp),colors=ButtonDefaults.buttonColors(containerColor=Navy),contentPadding=PaddingValues(6.dp)){Text("বই পড়ুন",fontSize=11.sp)}
                            OutlinedButton(onClick={onSchedule(book)},modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(11.dp),contentPadding=PaddingValues(6.dp)){Text("সময়সূচি",fontSize=11.sp)}
                            Text("বই মুছুন",color=Color(0xFFB45353),fontSize=10.sp,modifier=Modifier.align(Alignment.CenterHorizontally).clickable{onDelete(book)}.padding(5.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MessengerScreen(messages: List<ReadingMessage>, filter: String?, onStatus: (Long,String)->Unit, onOpenBook: (Long)->Unit) {
    val todayKey = SimpleDateFormat("yyyy-MM-dd",Locale.getDefault()).format(Date())
    val shown = when(filter) {
        "আজকের মোট পড়া" -> messages.filter { SimpleDateFormat("yyyy-MM-dd",Locale.getDefault()).format(Date(it.createdAt)) == todayKey }
        "সম্পূর্ণ পড়া" -> messages.filter { it.status == "সম্পন্ন" }
        "অসম্পূর্ণ পড়া" -> messages.filter { it.status != "সম্পন্ন" }
        else -> messages
    }
    Column(Modifier.fillMaxSize().padding(horizontal=16.dp)) {
        Text(filter ?: "মেসেঞ্জার",fontSize=22.sp,fontWeight=FontWeight.Bold,color=Navy,modifier=Modifier.padding(top=14.dp))
        Text("তোমার নির্ধারিত পড়াগুলো এখানে আসবে",fontSize=12.sp,color=Muted,modifier=Modifier.padding(bottom=12.dp))
        if(shown.isEmpty()) EmptyState("এখানে কোনো পড়া নেই","লাইব্রেরিতে বই যোগ করে সময়সূচি তৈরি করলে পড়া এখানে আসবে।")
        else LazyColumn(verticalArrangement=Arrangement.spacedBy(12.dp),contentPadding=PaddingValues(bottom=20.dp)) {
            items(shown) { msg ->
                Card(shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) {
                    Column(Modifier.padding(15.dp)) {
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Box(Modifier.size(36.dp).clip(CircleShape).background(Color(0xFFE7F2EE)),contentAlignment=Alignment.Center){Icon(Icons.Filled.MenuBook,null,tint=Green)}
                            Spacer(Modifier.width(9.dp)); Column(Modifier.weight(1f)){Text(msg.bookTitle,fontWeight=FontWeight.Bold,color=Ink,fontSize=13.sp);Text(formatDate(msg.createdAt),fontSize=10.sp,color=Muted)}
                            StatusPill(msg.status)
                        }
                        Spacer(Modifier.height(12.dp)); Text(msg.title,fontWeight=FontWeight.Bold,color=Navy,fontSize=15.sp)
                        Spacer(Modifier.height(8.dp)); Text(msg.content, fontSize=13.sp, lineHeight=21.sp, color=Ink)
                        Spacer(Modifier.height(12.dp)); Divider(color=Color(0xFFECEFF2)); Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                            if(msg.status!="সম্পন্ন") Button(onClick={onStatus(msg.id,"সম্পন্ন")},modifier=Modifier.weight(1f),shape=RoundedCornerShape(12.dp),colors=ButtonDefaults.buttonColors(containerColor=Green)){Icon(Icons.Filled.CheckCircle,null,modifier=Modifier.size(16.dp));Spacer(Modifier.width(4.dp));Text("পড়া সম্পন্ন",fontSize=11.sp)}
                            else FilledTonalButton(onClick={onStatus(msg.id,"অসম্পূর্ণ")},modifier=Modifier.weight(1f),shape=RoundedCornerShape(12.dp)){Text("আবার খুলুন",fontSize=11.sp)}
                            OutlinedButton(onClick={onOpenBook(msg.bookId)},modifier=Modifier.weight(1f),shape=RoundedCornerShape(12.dp)){Text("মূল বই খুলুন",fontSize=11.sp)}
                        }
                        if(msg.status!="সম্পন্ন") Text("পরে পড়ব",fontSize=11.sp,color=Green,modifier=Modifier.align(Alignment.End).clickable{onStatus(msg.id,"পরে পড়ব")}.padding(top=8.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun ProgressScreen(books: List<Book>, messages: List<ReadingMessage>) {
    val done = messages.filter { it.status == "সম্পন্ন" }
    val days = done.map { SimpleDateFormat("yyyy-MM-dd",Locale.getDefault()).format(Date(it.createdAt)) }.distinct().sortedDescending()
    LazyColumn(contentPadding=PaddingValues(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item { Text("পড়ার অগ্রগতি",fontSize=22.sp,fontWeight=FontWeight.Bold,color=Navy); Text("তোমার পড়াশোনার হিসাব",fontSize=12.sp,color=Muted) }
        item { Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) { SummaryTile("মোট বই",books.size.toString(),Modifier.weight(1f)); SummaryTile("সম্পন্ন পড়া",done.size.toString(),Modifier.weight(1f)); SummaryTile("বাকি পড়া",(messages.size-done.size).toString(),Modifier.weight(1f)) } }
        item { Card(shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){Column(Modifier.padding(16.dp)){Text("পড়ার ধারাবাহিকতা",fontWeight=FontWeight.Bold,color=Ink);Spacer(Modifier.height(8.dp));Text("${days.size} দিন পড়া সম্পন্ন হয়েছে",fontSize=23.sp,fontWeight=FontWeight.Bold,color=Green);Text("সম্পন্ন পড়া থাকা দিনগুলোর হিসাব",fontSize=11.sp,color=Muted)}} }
        item { Text("সম্পন্ন করার দিন",fontWeight=FontWeight.Bold,color=Ink,fontSize=16.sp) }
        items(days) { day -> Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color.White).padding(14.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Filled.CalendarMonth,null,tint=Green);Spacer(Modifier.width(10.dp));Text(day,color=Ink,fontWeight=FontWeight.Medium);Spacer(Modifier.weight(1f));Text("সম্পন্ন",color=Green,fontSize=11.sp)} }
        if(days.isEmpty()) item { EmptyState("এখনো অগ্রগতি নেই","মেসেঞ্জারের পড়া সম্পন্ন করলে এখানে হিসাব জমা হবে।") }
    }
}

@Composable
private fun SettingsScreen(activity: Activity, onLock: (Int)->Unit) {
    var custom by remember { mutableStateOf("20") }
    val dpm = activity.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
    val admin = ComponentName(activity,LockDeviceAdminReceiver::class.java)
    Column(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(14.dp)) {
        Text("সেটিংস",fontSize=22.sp,fontWeight=FontWeight.Bold,color=Navy)
        Card(shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment=Alignment.CenterVertically){Icon(Icons.Filled.Lock,null,tint=Green);Spacer(Modifier.width(8.dp));Text("স্ক্রিন লক টাইমার",fontSize=17.sp,fontWeight=FontWeight.Bold,color=Ink)}
                Text("সময় শেষ হলে ফোন লক হবে। যেকোনো অ্যাপ ব্যবহারের সময় চালু করতে পারো।",fontSize=12.sp,color=Muted)
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick={ if (Build.VERSION.SDK_INT >= 31) { val i = Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM); activity.startActivity(i) } }, shape=RoundedCornerShape(12.dp)) { Text("নির্দিষ্ট সময়ে অ্যালার্মের অনুমতি") }
                Spacer(Modifier.height(8.dp))
                if(!dpm.isAdminActive(admin)) Button(onClick={val i=Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN,admin).putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,"টাইমার শেষ হলে ফোন লক করার জন্য এই অনুমতি প্রয়োজন।");activity.startActivity(i)},colors=ButtonDefaults.buttonColors(containerColor=Navy),shape=RoundedCornerShape(12.dp)){Text("স্ক্রিন লক অনুমতি চালু করুন")}
                else Text("স্ক্রিন লক অনুমতি চালু আছে",color=Green,fontSize=12.sp)
                Spacer(Modifier.height(10.dp));Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf(5,10,15,30).forEach{n->OutlinedButton(onClick={onLock(n)},modifier=Modifier.weight(1f),contentPadding=PaddingValues(4.dp)){Text("$n মিনিট",fontSize=11.sp)}}}
                OutlinedTextField(value=custom,onValueChange={custom=it.filter(Char::isDigit).take(3)},label={Text("কাস্টম মিনিট")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),singleLine=true)
                Button(onClick={custom.toIntOrNull()?.takeIf{it in 1..1440}?.let(onLock)},colors=ButtonDefaults.buttonColors(containerColor=Green),shape=RoundedCornerShape(12.dp)){Text("কাস্টম টাইমার চালু")}
            }
        }
        Card(shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=Color.White)) { Column(Modifier.padding(16.dp)){Text("অ্যাপ সম্পর্কে",fontWeight=FontWeight.Bold,color=Ink);Text("আমার সহকারী · সংস্করণ ১.০.০",fontSize=12.sp,color=Muted);Text("বই, পড়ার সময়সূচি ও অগ্রগতি এই ফোনে সংরক্ষিত থাকে।",fontSize=12.sp,color=Muted)} }
    }
}

@Composable
private fun PdfReader(activity: Activity, book: Book, db: AppDatabase, onBack: ()->Unit) {
    var page by remember { mutableIntStateOf(book.lastPage.coerceIn(0,(book.pageCount-1).coerceAtLeast(0))) }
    var zoom by remember { mutableFloatStateOf(1f) }
    val bitmap = remember(book.filePath,page) { PdfTools.renderPage(File(book.filePath),page) }
    val transform = rememberTransformableState { scale,_,_-> zoom=(zoom*scale).coerceIn(1f,4f) }
    Column(Modifier.fillMaxSize().background(Color(0xFFE8EBEF))) {
        Row(Modifier.fillMaxWidth().background(Color.White).padding(12.dp),verticalAlignment=Alignment.CenterVertically){Text("‹",fontSize=30.sp,color=Navy,modifier=Modifier.clickable{db.updateLastPage(book.id,page);onBack()});Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(book.title,fontWeight=FontWeight.Bold,color=Ink,maxLines=1,overflow=TextOverflow.Ellipsis);Text("পৃষ্ঠা ${page+1} / ${book.pageCount}",fontSize=11.sp,color=Muted)};Text("−",fontSize=25.sp,color=Green,modifier=Modifier.clickable{zoom=(zoom-.25f).coerceAtLeast(1f)}.padding(8.dp));Text("+",fontSize=25.sp,color=Green,modifier=Modifier.clickable{zoom=(zoom+.25f).coerceAtMost(4f)}.padding(8.dp))}
        Box(Modifier.weight(1f).fillMaxWidth().padding(10.dp),contentAlignment=Alignment.Center) {
            if(bitmap!=null) Image(bitmap.asImageBitmap(),null,Modifier.fillMaxWidth().transformable(transform).graphicsLayer(scaleX=zoom,scaleY=zoom),contentScale=androidx.compose.ui.layout.ContentScale.Fit)
            else Text("এই পৃষ্ঠা দেখানো যাচ্ছে না",color=Muted)
        }
        Row(Modifier.fillMaxWidth().background(Color.White).padding(12.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween){OutlinedButton(onClick={page=(page-1).coerceAtLeast(0);zoom=1f}){Text("আগের পৃষ্ঠা")};Text("${page+1}",fontWeight=FontWeight.Bold,color=Navy);Button(onClick={page=(page+1).coerceAtMost(book.pageCount-1);zoom=1f},colors=ButtonDefaults.buttonColors(containerColor=Green)){Text("পরের পৃষ্ঠা")}}
    }
    LaunchedEffect(page) { db.updateLastPage(book.id,page) }
}

@Composable
private fun ScheduleDialog(book: Book, onDismiss: ()->Unit, onSave: (Int,Int,Int)->Unit) {
    var hour by remember { mutableStateOf("09") }; var minute by remember { mutableStateOf("00") }; var pages by remember { mutableStateOf("5") }
    AlertDialog(onDismissRequest=onDismiss, title={Text("পড়ার সময়সূচি",fontWeight=FontWeight.Bold)}, text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Text(book.title,color=Muted,fontSize=12.sp);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(hour,{hour=it.filter(Char::isDigit).take(2)},label={Text("ঘণ্টা")},modifier=Modifier.weight(1f),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number));OutlinedTextField(minute,{minute=it.filter(Char::isDigit).take(2)},label={Text("মিনিট")},modifier=Modifier.weight(1f),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))};OutlinedTextField(pages,{pages=it.filter(Char::isDigit).take(3)},label={Text("প্রতি বারে কত পৃষ্ঠা")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number));Text("সময় ২৪ ঘণ্টা ফরম্যাটে দাও। প্রতিদিন এই সময়ে পরবর্তী পৃষ্ঠাগুলো মেসেঞ্জারে আসবে।",fontSize=11.sp,color=Muted)}}, confirmButton={Button(onClick={val h=hour.toIntOrNull();val m=minute.toIntOrNull();val p=pages.toIntOrNull();if(h!=null&&m!=null&&p!=null&&h in 0..23&&m in 0..59&&p in 1..100)onSave(h,m,p)},colors=ButtonDefaults.buttonColors(containerColor=Green)){Text("সময়সূচি সংরক্ষণ")}}, dismissButton={OutlinedButton(onClick=onDismiss){Text("বাতিল")}})
}

@Composable private fun SummaryTile(title:String,value:String,modifier:Modifier){Card(modifier,shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){Column(Modifier.padding(12.dp)){Text(value,fontSize=22.sp,fontWeight=FontWeight.Bold,color=Navy);Text(title,fontSize=10.sp,color=Muted)}}}
@Composable private fun StatusPill(status:String){Text(status,fontSize=10.sp,color=if(status=="সম্পন্ন")Green else Color(0xFFB7791F),modifier=Modifier.clip(RoundedCornerShape(20.dp)).background(if(status=="সম্পন্ন")Color(0xFFE8F5EF) else Color(0xFFFFF4DF)).padding(horizontal=9.dp, vertical=5.dp))}
@Composable private fun MessagePreview(msg:ReadingMessage,onClick:()->Unit){Card(Modifier.fillMaxWidth().clickable(onClick),shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){Column(Modifier.padding(14.dp)){Row(verticalAlignment=Alignment.CenterVertically){Text(msg.bookTitle,fontWeight=FontWeight.Bold,color=Ink,modifier=Modifier.weight(1f));StatusPill(msg.status)};Text(msg.title,color=Green,fontSize=12.sp);Text(msg.content.take(110),color=Muted,fontSize=11.sp,maxLines=2,overflow=TextOverflow.Ellipsis)}}}
@Composable private fun EmptyState(title:String,subtitle:String){Column(Modifier.fillMaxWidth().padding(vertical=40.dp),horizontalAlignment=Alignment.CenterHorizontally){Box(Modifier.size(70.dp).clip(CircleShape).background(Color(0xFFEAF1F3)),contentAlignment=Alignment.Center){Icon(Icons.Filled.AutoStories,null,tint=Green,modifier=Modifier.size(32.dp))};Spacer(Modifier.height(12.dp));Text(title,fontWeight=FontWeight.Bold,color=Ink);Text(subtitle,color=Muted,fontSize=12.sp,modifier=Modifier.padding(top=4.dp))}}
@Composable private fun LinearProgressText(text:String){Text(text,color=Green,fontSize=12.sp,modifier=Modifier.padding(8.dp))}
private fun queryDisplayName(context:Context,uri:Uri):String { var name="বই.pdf";context.contentResolver.query(uri,null,null,null,null)?.use{c->if(c.moveToFirst()){val i=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(i>=0)name=c.getString(i)}};return name }
private fun currentStreak(messages: List<ReadingMessage>): Int {
    val completedDays = messages.filter { it.status == "সম্পন্ন" }.map { SimpleDateFormat("yyyy-MM-dd",Locale.getDefault()).format(Date(it.createdAt)) }.toSet()
    var date = java.time.LocalDate.now()
    if (!completedDays.contains(date.toString())) date = date.minusDays(1)
    var count = 0
    while (completedDays.contains(date.toString())) { count++; date = date.minusDays(1) }
    return count
}
private fun greeting()=when(Calendar.getInstance().get(Calendar.HOUR_OF_DAY)){in 5..11->"শুভ সকাল";in 12..16->"শুভ দুপুর";in 17..19->"শুভ সন্ধ্যা";else->"শুভ রাত্রি"}
private fun formatDate(time:Long)=SimpleDateFormat("dd MMM yyyy, hh:mm a",Locale.getDefault()).format(Date(time))
private fun startLock(activity:Activity,minutes:Int){val dpm=activity.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager;val admin=ComponentName(activity,LockDeviceAdminReceiver::class.java);if(dpm.isAdminActive(admin))schedulePhoneLock(activity,minutes) else {val i=Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN,admin).putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,"টাইমার শেষে ফোন লক করার অনুমতি প্রয়োজন।");activity.startActivity(i)}}
